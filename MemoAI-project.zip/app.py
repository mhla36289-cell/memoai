import base64
import os
import re
import secrets
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

from flask import Flask, jsonify, redirect, render_template, request, session, url_for, send_from_directory
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
UPLOAD_DIR = BASE_DIR / "uploads"
ENV_FILE = BASE_DIR / ".env"
INSTANCE_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(exist_ok=True)

# Minimal .env loader so the app works without exposing secrets to the browser.
if ENV_FILE.exists():
    for raw_line in ENV_FILE.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv("FLASK_SECRET_KEY", secrets.token_hex(32)),
    MAX_CONTENT_LENGTH=12 * 1024 * 1024,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
ALLOWED_MIME_PREFIX = "image/"
MEDIA_API_KEY = os.getenv("MEDIA_API_KEY", "")  # server-only; never sent to the client


def db():
    conn = sqlite3.connect(INSTANCE_DIR / "memoai.sqlite3")
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS subscribers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                phone TEXT NOT NULL,
                created_at TEXT NOT NULL,
                last_seen TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS operations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subscriber_id INTEGER NOT NULL,
                mode TEXT NOT NULL,
                prompt TEXT DEFAULT '',
                source_files TEXT DEFAULT '',
                output_file TEXT DEFAULT '',
                status TEXT NOT NULL DEFAULT 'completed',
                created_at TEXT NOT NULL,
                FOREIGN KEY(subscriber_id) REFERENCES subscribers(id)
            );
            """
        )


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def valid_email(email):
    return bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email or ""))


def valid_phone(phone):
    return bool(re.fullmatch(r"[+()\d][\d\s().-]{6,22}", phone or ""))


def current_user():
    return session.get("user")


def admin_required():
    return bool(session.get("is_admin"))


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def save_data_url(data_url):
    match = re.match(r"^data:image/(png|jpeg|jpg|webp);base64,(.+)$", data_url or "", re.DOTALL)
    if not match:
        return None
    ext = "jpg" if match.group(1) in {"jpeg", "jpg"} else match.group(1)
    raw = base64.b64decode(match.group(2), validate=True)
    if len(raw) > 8 * 1024 * 1024:
        return None
    name = f"generated-{uuid.uuid4().hex}.{ext}"
    (UPLOAD_DIR / name).write_bytes(raw)
    return name


@app.get("/")
def index():
    return render_template("index.html", user=current_user())


@app.post("/api/auth/login")
def login():
    payload = request.get_json(silent=True) or {}
    email = (payload.get("email") or "").strip().lower()
    phone = (payload.get("phone") or "").strip()
    if not valid_email(email) or not valid_phone(phone):
        return jsonify(error="يرجى إدخال بريد إلكتروني ورقم هاتف صحيحين."), 400
    timestamp = now_iso()
    with db() as conn:
        conn.execute(
            "INSERT INTO subscribers(email, phone, created_at, last_seen) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(email) DO UPDATE SET phone=excluded.phone, last_seen=excluded.last_seen",
            (email, phone, timestamp, timestamp),
        )
        row = conn.execute("SELECT * FROM subscribers WHERE email=?", (email,)).fetchone()
    session["user"] = {"id": row["id"], "email": row["email"], "phone": row["phone"]}
    return jsonify(user=session["user"])


@app.post("/api/auth/logout")
def logout():
    session.pop("user", None)
    return jsonify(ok=True)


@app.get("/api/session")
def session_status():
    return jsonify(user=current_user())


@app.post("/api/upload")
def upload():
    if not current_user():
        return jsonify(error="يرجى تسجيل الدخول أولاً."), 401
    uploaded = request.files.get("file")
    if not uploaded or not uploaded.filename or not allowed_file(uploaded.filename):
        return jsonify(error="يرجى اختيار صورة PNG أو JPG أو WEBP."), 400
    if uploaded.mimetype and not uploaded.mimetype.startswith(ALLOWED_MIME_PREFIX):
        return jsonify(error="نوع الملف غير مسموح."), 400
    filename = f"source-{uuid.uuid4().hex}-{secure_filename(uploaded.filename)}"
    uploaded.save(UPLOAD_DIR / filename)
    return jsonify(filename=filename, url=url_for("media", filename=filename))


@app.post("/api/generate")
def generate():
    user = current_user()
    if not user:
        return jsonify(error="يرجى تسجيل الدخول أولاً."), 401
    payload = request.get_json(silent=True) or {}
    mode = payload.get("mode") if payload.get("mode") in {"hug", "merge", "animate", "cinematic"} else "cinematic"
    prompt = (payload.get("prompt") or "").strip()[:500]
    source_files = [str(x) for x in (payload.get("source_files") or []) if isinstance(x, str)][:3]
    output_file = save_data_url(payload.get("preview_data"))
    if not output_file:
        return jsonify(error="تعذر حفظ المعاينة المحلية."), 400
    with db() as conn:
        cur = conn.execute(
            "INSERT INTO operations(subscriber_id, mode, prompt, source_files, output_file, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (user["id"], mode, prompt, ",".join(source_files), output_file, "completed", now_iso()),
        )
        op_id = cur.lastrowid
    return jsonify(
        operation={"id": op_id, "mode": mode, "status": "completed"},
        output_url=url_for("media", filename=output_file),
        message="تمت المحاكاة محلياً بنجاح؛ لم يتم استدعاء خدمة خارجية.",
    )


@app.post("/api/operations/<int:operation_id>/share")
def share(operation_id):
    user = current_user()
    with db() as conn:
        row = conn.execute("SELECT * FROM operations WHERE id=?", (operation_id,)).fetchone()
    if not row or not user or row["subscriber_id"] != user["id"]:
        return jsonify(error="العملية غير متاحة."), 404
    share_url = url_for("media", filename=row["output_file"], _external=True)
    return jsonify(url=share_url, text="شاهد تجربة MemoAI المحلية")


@app.get("/media/<path:filename>")
def media(filename):
    return send_from_directory(UPLOAD_DIR, filename, as_attachment=False)


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        password = request.form.get("password", "")
        if secrets.compare_digest(password, os.getenv("ADMIN_PASSWORD", "change-me")):
            session["is_admin"] = True
            return redirect(url_for("dashboard"))
        return render_template("admin_login.html", error="بيانات الدخول غير صحيحة."), 401
    return render_template("admin_login.html", error=None)


@app.post("/admin/logout")
def admin_logout():
    session.pop("is_admin", None)
    return redirect(url_for("admin_login"))


@app.get("/dashboard")
def dashboard():
    if not admin_required():
        return redirect(url_for("admin_login"))
    with db() as conn:
        subscribers = conn.execute("SELECT * FROM subscribers ORDER BY last_seen DESC").fetchall()
        operations = conn.execute(
            "SELECT o.*, s.email FROM operations o JOIN subscribers s ON s.id=o.subscriber_id ORDER BY o.created_at DESC"
        ).fetchall()
        metrics = {
            "subscribers": conn.execute("SELECT COUNT(*) FROM subscribers").fetchone()[0],
            "operations": conn.execute("SELECT COUNT(*) FROM operations").fetchone()[0],
            "completed": conn.execute("SELECT COUNT(*) FROM operations WHERE status='completed'").fetchone()[0],
        }
    return render_template("dashboard.html", subscribers=subscribers, operations=operations, metrics=metrics)


@app.get("/health")
def health():
    return jsonify(status="ok", app="MemoAI", simulation=True, server_key_configured=bool(MEDIA_API_KEY))


@app.errorhandler(413)
def too_large(_error):
    return jsonify(error="حجم الصورة يتجاوز 12 ميغابايت."), 413


init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False)
