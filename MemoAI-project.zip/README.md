# MemoAI Local Creative Lab

Arabic RTL Flask application for local simulation of image hugging, merging, animation, and cinematic generation.

## Run

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Local dashboard

Open `/dashboard`. The demo admin password is stored only in `.env` as `ADMIN_PASSWORD`.

## Security notes

- The media API key is read only by Flask from `.env`; it is never returned to the browser.
- This Sandbox build intentionally simulates generation locally by composing uploaded images on a browser canvas, then stores the preview in the local `uploads/` directory.
- Rotate the supplied API key before production because it was previously pasted into client-side files.
- For production, replace the local simulation in `/api/generate` with a server-side provider call, add CSRF protection, a real identity provider, object storage, rate limiting, and HTTPS-only cookies.
